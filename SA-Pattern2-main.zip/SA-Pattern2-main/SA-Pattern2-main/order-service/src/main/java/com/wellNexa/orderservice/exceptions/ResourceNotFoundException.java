package com.wellNexa.orderservice.exceptions;

public class ResourceNotFoundException extends Exception {
    public ResourceNotFoundException(String s) {
        super(s);
    }
}
