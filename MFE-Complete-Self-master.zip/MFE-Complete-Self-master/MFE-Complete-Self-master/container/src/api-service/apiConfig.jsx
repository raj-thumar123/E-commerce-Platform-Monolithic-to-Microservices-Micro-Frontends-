// const API_BASE_URL = "http://localhost:8080"
// const API_BASE_URL = "http://172.17.83.218:8080"
const API_BASE_URL = "http://172.17.48.111:8080"

export default API_BASE_URL;