package com.wellNexa.userservice.enums;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
