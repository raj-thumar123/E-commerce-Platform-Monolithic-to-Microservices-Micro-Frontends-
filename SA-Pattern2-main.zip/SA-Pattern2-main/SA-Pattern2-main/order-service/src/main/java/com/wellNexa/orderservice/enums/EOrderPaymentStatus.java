package com.wellNexa.orderservice.enums;

public enum EOrderPaymentStatus {
    PAID,
    PAID_
}
