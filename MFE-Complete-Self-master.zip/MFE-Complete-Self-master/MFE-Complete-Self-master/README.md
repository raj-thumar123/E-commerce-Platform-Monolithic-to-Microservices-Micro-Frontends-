# MFE-Complete-Self
A Micro-Frontend Project of E-Commerce in React js
