package com.wellNexa.cartservice.exceptions;

public class ServiceLogicException extends Exception{
    public ServiceLogicException(String message) {
        super(message);
    }
}
