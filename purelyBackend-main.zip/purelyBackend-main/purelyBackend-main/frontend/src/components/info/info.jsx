function Info({message}) {
    return (
        <main className="flex-center">
            <small>{message}</small>
        </main>
    )
}

export default Info;